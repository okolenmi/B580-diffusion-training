Round-3 reproductions (docs/design/backend/10-review-round-3.md). Run from the repo root with COMFY_DIR set to an empty dir.
r14_watcher_crash_live_child.py   N3-01  transient read error -> row failed, child still alive, no stop/kill sent
r16_graph_finished_while_down.py  N3-02  child finished while server down -> row failed 0/3 results
r15_stale_event_id.py             N3-04  replay_since(40) from a previous process returns complete=True
Others (no script needed):
  N3-03  python3 -c "from backend.tests.support import finish; finish()"      # prints ALL CHECKS PASSED, exit 0
  N3-05  env -u COMFY_DIR python3 backend/tests/run_all.py                    # 3-4 files fail on a bare checkout
  N3-06  python3.12 -c "from backend.presentation.event_schema import schema_for; schema_for('run_progressed')"
