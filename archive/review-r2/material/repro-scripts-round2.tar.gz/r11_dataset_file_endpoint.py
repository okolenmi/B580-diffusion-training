"""N-06: /datasets/{name}/files/{path} serves any file in the dataset dir (db, shards, svg) -- not just previews."""
import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, os.environ.get("REPO","."))
from backend.tests.support import build_services, asgi_request
from backend.presentation.app import create_app
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    svc = build_services(project_root=tmp/"proj", runs_dir=tmp/"runs"); app = create_app(svc)
    st,_,b = asgi_request(app,"/api/v1/datasets",method="POST",json_body={"name":"ds"}); print("create dataset ->", st)
    root = svc.datasets.read_file._files.read.__self__._datasets_dir / "ds"
    (root/"shards"/"big.safetensors").write_bytes(b"\0"*5_000_000)
    (root/"previews"/"x.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)"/>')
    for rel in ("metadata.db","shards/big.safetensors","previews/x.svg"):
        st,hdr,body = asgi_request(app,f"/api/v1/datasets/ds/files/{rel}")
        h = {k.lower():v for k,v in (hdr if isinstance(hdr,dict) else dict(hdr)).items()}
        print(f"GET files/{rel:24s} -> {st}  {len(body) if body else 0:>8} bytes  content-type={h.get('content-type')}  nosniff={'x-content-type-options' in h}  CSP={'content-security-policy' in h}  disposition={h.get('content-disposition')}")
