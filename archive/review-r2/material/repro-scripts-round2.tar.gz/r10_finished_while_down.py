"""N-03: a trainer that FINISHED while the server was down is recorded as failed at the next start."""
import os, sys, json, tempfile
from pathlib import Path
sys.path.insert(0, os.environ.get("REPO","."))
from backend.tests.support import (FakeClock, FakeConfigInspector, FakeTrainingGateway,
    InMemoryRunRepository, RecordingEventBus, build_services, seed_run)
from backend.infrastructure.jsonl_progress_source import JsonlProgressSource

with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp); repo = InMemoryRunRepository(); gw = FakeTrainingGateway(); clock = FakeClock()
    svc = build_services(runs=repo, events=RecordingEventBus(), gateway=gw, inspector=FakeConfigInspector(),
                         clock=clock, project_root=tmp/"proj", runs_dir=tmp/"runs")
    run = seed_run(repo, clock, total_steps=100, start=True, pid=4242)          # the 'running' row left by the old server
    prog = tmp/"runs"/f"run_{run.id}"/"log.progress.jsonl"; prog.parent.mkdir(parents=True)
    with open(prog,"w") as f:                                                      # what the trainer wrote before exiting 0
        f.write(json.dumps({"phase":"training_start","total_steps":100})+"\n")
        for s in range(1,101): f.write(json.dumps({"phase":"step","step":s,"total":100,"loss":0.1,"avg":0.1,"lr":1e-4})+"\n")
        f.write(json.dumps({"phase":"finished"})+"\n")
    gw.alive.discard(4242)                                                         # trainer is gone; nobody read its exit code
    svc.reconcile_runs.execute()
    r = repo.get(run.id)
    print(f"progress file says: 100/100 + 'finished'   ->   row says: status={r.status.value} done={r.done_steps}/{r.total_steps} error={r.error!r}")
