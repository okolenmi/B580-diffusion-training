Reproductions for docs/design/backend/07-review-2026-10-01.md and 08-review-2026-10-02.md
Run from the repo root (or set REPO=/path/to/repo):  python3 /path/to/rN_*.py
Deps: the repo's requirements + uvicorn, httpx (r9). CPU is enough.

ROUND 1 (against 5b7724f these now show the FIXED behaviour -- they work as regression checks)
r1_supervisor.py      F-07/F-01/F-02   r2_write_chain.py  F-06/F-15   r3_raw_toml.py  F-08
r4_torn.py            F-07 (+NaN read) r5_runid_collision.py F-04 (now refused)
r6_migration.py       F-16 (atomic)    r7_discard.py      F-05 (rows first, orphan logged)
r8_nan.py             F-03 (strict JSON now)

ROUND 2 (these demonstrate NEW findings; they show the PROBLEM until fixed)
r9_upload_blocking.py          N-02  event-loop stall + ~2x RAM during a 600 MB upload (real uvicorn)
r10_finished_while_down.py     N-03  finished run recorded failed 0/100 after a server restart
r11_dataset_file_endpoint.py   N-05  files endpoint serves metadata.db, shards, svg
r13_sse_coalescing.py          N-04  6 graph node frames -> 1 delivered
r12_verify_fixes.py            F-10 now returns 409 and keeps the user's files (verification only)
Each script prints what it observed; none modify the repo (temp dirs only).
