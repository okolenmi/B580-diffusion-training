"""N-04: ClientBuffer coalesces per-node graph deltas as if they were absolute state."""
import asyncio, os, sys, json
sys.path.insert(0, os.environ.get("REPO","."))
from backend.presentation.sse import ClientBuffer
async def main():
    b = ClientBuffer()
    for n in "ABCDEF":
        b.put("graph_execution_progressed", json.dumps({"node_id": n, "ok": True}))
    got=[]
    while len(b): got.append(json.loads(await b.get(0.1))["node_id"])
    print("published nodes A..F | delivered:", got, "| coalesced:", b.coalesced)
    b2 = ClientBuffer(); b2.put("graph_execution_progressed", json.dumps({"node_id":"X"})); b2.put("run_progressed", json.dumps({"step":1}))
    print("graph frame after a run_progressed:", [json.loads(await b2.get(0.1)) for _ in range(len(b2))], "(X was evicted)")
asyncio.run(main())
