Round-5 reproductions (run from the repo root; COMFY_DIR must point at any empty dir)
r19_checkpoint_dropout.py       R5-01  checkpoint recompute draws a different dropout mask: 43% (p=0.1) / 93% (p=0.5) gradient error; control (torch.utils.checkpoint) is exact
r20_install_denylist_bypass.py  R5-02  install guard accepts torch==2.5.0, Torch, torch[opt], torch>=1, pytorch-triton-xpu; accepts '--index-url=...' and '-r ...' as packages
r17b_readiness_cached.py        verification of the round-4 readiness fix: 8 concurrent requests -> 1 probe (was 8)
R5-03: python3 backend/tests/test_environment_port.py   (3 failures on a machine with no XPU)
R5-04: run 4 copies of backend/tests/test_process_identity.py in parallel; ~1 in 12 fails on a 1-core box
Note: r19 stubs ComfyUI's module slot, so it needs no ComfyUI install. r20 runs no real pip.
