import os, sys, tempfile
from pathlib import Path
sys.path.insert(0, os.environ.get("REPO","."))
from backend.tests.support import build_services, asgi_request
from backend.presentation.app import create_app
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp); svc=build_services(project_root=tmp/"proj", runs_dir=tmp/"runs"); app=create_app(svc)
    # F-10: a user's raw image folder happens to share the name
    ds_root = svc.datasets.read_file._files._datasets_dir
    mine = ds_root/"portraits"; mine.mkdir(parents=True); (mine/"photo1.png").write_bytes(b"x"*1000); (mine/"notes.txt").write_text("keep me")
    st,_,b = asgi_request(app,"/api/v1/datasets",method="POST",json_body={"name":"portraits"})
    print("F-10  create over foreign dir ->", st, "| user files survive:", (mine/"photo1.png").exists() and (mine/"notes.txt").exists())
    # run log tail on a big log with multi-byte chars
    from backend.application.dto import StartTrainingCommand
    import time
    d = tmp/"runs"/"run_9"; d.mkdir(parents=True)
    (d/"log.txt").write_text("".join(f"line {i} ünïcödé ✓\n" for i in range(200000)), encoding="utf-8")
    t=time.perf_counter(); out = svc.get_run_log.execute(9, lines=5) if hasattr(svc,'get_run_log') else None
    print("log tail call ->", type(out).__name__, f"{(time.perf_counter()-t)*1000:.0f} ms")
