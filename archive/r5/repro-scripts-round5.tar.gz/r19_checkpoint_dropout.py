"""N5-01: the project's checkpoint function recomputes a block with a DIFFERENT dropout mask than the forward used."""
import os, sys, types, torch
sys.path.insert(0, os.environ.get("REPO","."))
# stand-in for ComfyUI's module slot that enable_frozen_param_safe_checkpointing() patches
for name in ("comfy","comfy.ldm","comfy.ldm.modules","comfy.ldm.modules.diffusionmodules","comfy.ldm.modules.diffusionmodules.util"):
    sys.modules[name] = types.ModuleType(name)
util = sys.modules["comfy.ldm.modules.diffusionmodules.util"]
class _Stock(torch.autograd.Function): pass
util.CheckpointFunction = _Stock
from nodes.model.gradient_checkpointing import enable_frozen_param_safe_checkpointing
enable_frozen_param_safe_checkpointing()
Ours = util.CheckpointFunction

class Block(torch.nn.Module):
    """frozen base linear + LoRA path with dropout, the way the LoRA layers in nodes/model/lora_phases.py do it"""
    def __init__(self, p):
        super().__init__(); g = torch.Generator().manual_seed(0)
        self.base = torch.nn.Linear(64, 64); self.base.requires_grad_(False)
        self.A = torch.nn.Parameter(torch.randn(8, 64, generator=g)*0.1); self.B = torch.nn.Parameter(torch.randn(64, 8, generator=g)*0.1)
        self.drop = torch.nn.Dropout(p)
    def forward(self, x): return self.base(x) + (self.drop(x) @ self.A.T) @ self.B.T

x0 = torch.randn(16, 64, generator=torch.Generator().manual_seed(1))
def grad_of(block, how, seed=123):
    block.train(); block.A.grad = block.B.grad = None
    x = x0.clone().requires_grad_(True); torch.manual_seed(seed)
    if how == "plain": y = block(x)
    elif how == "ours": y = Ours.apply(block.forward, 1, x, *[p for p in block.parameters()])
    elif how == "torch": y = torch.utils.checkpoint.checkpoint(block.forward, x, use_reentrant=True, preserve_rng_state=True)
    (y.pow(2).sum()).backward()
    return block.A.grad.clone(), block.B.grad.clone()
for p in (0.0, 0.1, 0.5):
    b = Block(p); ref = grad_of(b, "plain")
    for how in ("ours", "torch"):
        g = grad_of(b, how)
        rel = max(((g[i]-ref[i]).norm()/ref[i].norm()).item() for i in (0,1))
        print(f"dropout={p:<4} {how:5s} vs uncheckpointed: relative gradient error {rel:.3e}")
