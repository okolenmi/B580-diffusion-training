"""N-02: a large upload (a) stalls the event loop for its whole write, (b) holds ~2x the file in RAM."""
import os, sys, threading, time, tempfile, http.client, resource
from pathlib import Path
sys.path.insert(0, os.environ.get("REPO","."))
import uvicorn
from backend.tests.support import build_services
from backend.presentation.app import create_app

SIZE = 600 * 1024 * 1024
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    svc = build_services(project_root=tmp/"proj", runs_dir=tmp/"runs")
    app = create_app(svc)
    cfg = uvicorn.Config(app, host="127.0.0.1", port=18766, log_level="error")
    server = uvicorn.Server(cfg); threading.Thread(target=server.run, daemon=True).start()
    for _ in range(50):
        try: http.client.HTTPConnection("127.0.0.1",18766,timeout=1).request("GET","/api/v1/health"); break
        except OSError: time.sleep(0.1)
    # find a cheap GET to probe latency
    probe_path = "/api/v1/health"
    lat, stop = [], threading.Event()
    def prober():
        while not stop.is_set():
            t=time.perf_counter()
            try:
                c=http.client.HTTPConnection("127.0.0.1",18766,timeout=30); c.request("GET",probe_path); r=c.getresponse(); r.read(); c.close()
                lat.append((time.perf_counter()-t, r.status))
            except Exception as e: lat.append((time.perf_counter()-t, repr(e)))
            time.sleep(0.02)
    th=threading.Thread(target=prober); th.start(); time.sleep(0.3)
    base=[l for l,_ in lat]; print(f"idle  : max latency {max(base)*1000:.0f} ms over {len(base)} probes (status {lat[0][1]})")
    lat.clear()
    body = os.urandom(1024*1024) * (SIZE//(1024*1024))
    rss0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    c = http.client.HTTPConnection("127.0.0.1",18766,timeout=300)
    t=time.perf_counter()
    c.request("PUT","/api/v1/assets/lora/files/big.safetensors",body=body,headers={"Content-Type":"application/octet-stream"})
    r=c.getresponse(); r.read(); dt=time.perf_counter()-t
    stop.set(); th.join()
    rss1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
    print(f"upload: {SIZE/2**20:.0f} MB -> HTTP {r.status} in {dt:.1f}s")
    print(f"during: probes served {len(lat)}, worst latency {max(l for l,_ in lat)*1000:.0f} ms")
    print(f"peak RSS {rss0:.0f} -> {rss1:.0f} MB (includes this script's own {SIZE/2**20:.0f} MB body)")
    server.should_exit=True
